/**
 *
 * @author Jesus Zabdiel Sanchez Chavez A01374964
 */
public class Equipo {
    
    private int puntos;
    
    public Equipo(int puntos){
        this.puntos = puntos;        
    }
    
    public int getPuntos(){        
        return this.puntos;
    }
    
}
