
/**
 *
 * @author Jesus Zabdiel Sánchez Chavez A01374964
 */
public interface Cargable {
    
    void cargarDatos(String nombreArchivo);
}
